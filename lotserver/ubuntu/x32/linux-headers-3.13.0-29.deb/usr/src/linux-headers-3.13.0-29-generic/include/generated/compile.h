/* This file is auto generated, version 53-Ubuntu */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#53-Ubuntu SMP Wed Jun 4 21:02:19 UTC 2014"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "brownie"
#define LINUX_COMPILER "gcc version 4.8.2 (Ubuntu 4.8.2-19ubuntu1) "
