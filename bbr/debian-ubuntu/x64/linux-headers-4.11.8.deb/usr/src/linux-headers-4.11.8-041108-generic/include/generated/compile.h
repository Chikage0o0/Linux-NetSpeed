/* This file is auto generated, version 201706290836 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201706290836 SMP Thu Jun 29 12:38:45 UTC 2017"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "tangerine"
#define LINUX_COMPILER "gcc version 6.3.0 20170618 (Ubuntu 6.3.0-19ubuntu1) "
